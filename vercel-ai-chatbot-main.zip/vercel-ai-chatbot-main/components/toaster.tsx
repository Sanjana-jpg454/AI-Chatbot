'use client'

export { Toaster } from 'react-hot-toast'
